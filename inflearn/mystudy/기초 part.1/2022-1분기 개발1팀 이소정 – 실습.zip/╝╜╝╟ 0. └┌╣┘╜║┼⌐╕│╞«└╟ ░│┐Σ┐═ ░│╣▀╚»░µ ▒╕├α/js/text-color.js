
        // heading 변수 선언, h1 태그 할당
        var heading = document.querySelector('#heading');

        // heading 클릭시 함수 실행
        heading.onclick = function (){
            heading.style.color = 'red'
        }
